function Y = uq_SVR_test_function_1d(X)

Y = 4 .* X.^2 .*(X.^2 - 1) - 0.5 .* X.^2 + 1 ;

end