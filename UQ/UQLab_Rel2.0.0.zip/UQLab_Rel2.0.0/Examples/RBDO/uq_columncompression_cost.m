function Y = uq_columncompression_cost(X) 

Y = X(:,1) .* X(:,2) ;

end